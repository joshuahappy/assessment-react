import React from "react";

const DonePage = () => {
  return <div>Done</div>;
};

export default DonePage;
