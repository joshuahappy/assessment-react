import React from "react";
import { useState } from "react";
import "./AddForm.css";

const AddForm = (props) => {
  const [content, setContent] = useState("");

  function handleAddForm(e) {
    e.preventDefault();
    const newContent = {
      content: content,
    };
    const newContents = [...props.todo, newContent];
    props.setTodo(newContents);
  }

  return (
    <form className="form" onSubmit={handleAddForm}>
      <input
        className="input"
        placeholder="Add to your todo list"
        value={content}
        onChange={e => setContent(e.target.value)}
      />
      <button className="add-button">Add</button>
    </form>
  );
};

export default AddForm;
