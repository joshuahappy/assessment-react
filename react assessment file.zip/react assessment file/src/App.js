import { Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import NotFoundPage from "./pages/NotFoundPage";
import DonePage from "./pages/DonePage";
import PendingPage from "./pages/PendingPage";
import MainHeader from "./components/MainHeader";
function App() {
  return (
    <div>
      <MainHeader />
      <main>
        <Routes>
          <Route path="" element={<HomePage />} />
          <Route path="/pending" element={<PendingPage />} />
          <Route path="/done" element={<DonePage />} />
          <Route path="/*" element={<NotFoundPage />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
