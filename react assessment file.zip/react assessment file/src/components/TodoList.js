
import "./TodoList.css";

const TodoList = (props) => {


  return (
    <div className="todo-list">
      <div className="header">
        <p className="pending">Pending</p>
      </div>

      {props.todo.map((todo) => (
        <div key={todo.name}>
          <div className="divider" />
          <div className="list">
            <div className="todo">{todo.name}</div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TodoList;
