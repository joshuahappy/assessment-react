import React from "react";
import AddForm from "../components/AddForm";
import TodoList from "../components/TodoList";
import { useState, useEffect } from "react";
const PendingPage = () => {
  const [todo, setTodo] = useState([]);
  const url = "https://jsonplaceholder.typicode.com/users";

  async function getUsersInit() {
    const response = await fetch(url);

    const data = await response.json();
    setTodo(data.slice(0,5));
    
  }
  useEffect(() => {
    getUsersInit();
  }, []);


  return <div>

    <AddForm todo={todo} setTodo={setTodo}/>
    <TodoList todo={todo}/>
  </div>;
};

export default PendingPage;
