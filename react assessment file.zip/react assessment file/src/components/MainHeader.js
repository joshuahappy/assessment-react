import React from "react";
import { Link } from "react-router-dom";
import classes from "./MainHeader.module.css";

const MainHeader = () => {
  return (
    
    <header className={classes.header}>
      <nav>
        <ul>
          <p className="logo">TODO</p>
          <li>
            <Link to="">Home</Link>
          </li>
          <li>
            <Link to="/pending">Pending</Link>
          </li>
          <li>
            <Link to="/done">Done</Link>
          </li>
        </ul>
      </nav>
    </header>
    
  );
};

export default MainHeader;
